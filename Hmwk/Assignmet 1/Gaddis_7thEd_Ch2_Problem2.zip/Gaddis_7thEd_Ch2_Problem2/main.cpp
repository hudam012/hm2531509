/* 
 * File:   main.cpp
 * Author: Huda Milbes
 * Assignment 1
 *
 * Created on June 30, 2014, 1:04 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    float sales; // Total Sales of Company
    float gnrt; // COmpanie's Generation
    
    sales = 4600000;
    gnrt = sales * .62;
    
    cout<< "Company Generates "<< gnrt <<endl;
            
            
            

    return 0;
}

