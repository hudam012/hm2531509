/* 
 * File:   main.cpp
 * Author: Huda Milbes
 * Assignment 1
 *
 * Created on June 30, 2014, 12:17 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    cout<<"Huda Milbes"<<endl;
    cout<<"10965 Carriage Dr, Rancho Cucamonga, CA, 91737"<<endl;
    cout<<"(909) 466-1772"<<endl;
    cout<<"Chemical Engineering"<<endl;

    return 0;
}

