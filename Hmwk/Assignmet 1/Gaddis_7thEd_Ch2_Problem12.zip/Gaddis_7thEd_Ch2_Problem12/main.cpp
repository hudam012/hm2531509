/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on June 25, 2014, 8:51 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    cout<<"   *"<<endl;
    cout<<"  ***"<<endl;
    cout<<" *****"<<endl;
    cout<<"*******"<<endl;
    cout<<" *****"<<endl;
    cout<<"  ***"<<endl;
    cout<<"   *"<<endl;

    return 0;
}

