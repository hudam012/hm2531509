/* 
 * File:   main.cpp
 * Author: Huda Milbes
 * Assignment 1
 *
 * Created on June 30, 2014, 11:53 AM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    int number1; 
    number1 = 62;
    cout<<"The value of number 1 is " << number1 <<endl;
    
    int number2;
    number2 = 99;
    cout<<"The value of number 2 is " << number2 <<endl;
    
    cout<<"total = 161"<<endl;
           
    
  
    
    
    
         
            
    
    

    return 0;
}

